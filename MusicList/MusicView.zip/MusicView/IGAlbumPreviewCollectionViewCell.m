//
//  IGAlbumPreviewCollectionViewCell.m
//  CameraDemo
//
//  Created by sharui on 2016/10/12.
//  Copyright © 2016年 sharui. All rights reserved.
//

#import "IGAlbumPreviewCollectionViewCell.h"


@interface IGAlbumPreviewCollectionViewCell()<UIScrollViewDelegate>
@property (nonatomic,strong)UIImageView *imageView;

/**
 背景图片
 */
@property (nonatomic,strong)UIScrollView *scroll;
/**
 预览界面图片
 */
@property (nonatomic,strong)UIImage *conImage;
@end

@implementation IGAlbumPreviewCollectionViewCell

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self){
        
        _scroll = [[UIScrollView alloc]initWithFrame:CGRectZero];
        _scroll.minimumZoomScale = 1;
        _scroll.maximumZoomScale = 2;
        _scroll.delegate = self;
        _scroll.directionalLockEnabled = YES;
        _imageView = [[UIImageView alloc]initWithFrame:CGRectZero];
        
//        UITapGestureRecognizer*tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(Actiondo)];
//        tapGesture.numberOfTapsRequired = 1;
//        [_scroll addGestureRecognizer:tapGesture];
        _scroll.userInteractionEnabled = NO;
        [self.imageView setContentMode: UIViewContentModeScaleAspectFit];
        [_scroll addSubview:_imageView];
        [self.contentView addSubview:_scroll];
        
        
    }
    return self;
}


- (void)setConImage:(UIImage *)conImage{
    _conImage = conImage;
 
    [self setNeedsLayout];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    if (_conImage != nil) {
        _scroll.zoomScale = 1;
        CGFloat w = kScreenWidth;
        CGFloat h = _conImage.size.height /_conImage.size.width* w;
        
        NSLog(@"图片的大小:w = %f  h = %f",w,h);
        _scroll.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight);
        _scroll.contentSize = CGSizeMake(kScreenWidth, h);
        
        _imageView.frame = CGRectMake(0, (kScreenHeight-h)/2, kScreenWidth, h);
        [_imageView setImage:_conImage];
    }
}

- (void)Actiondo {
    
    if ([self.delegate respondsToSelector:@selector(didSelectItemAtIndexPath:)]){
    
        [self.delegate didSelectItemAtIndexPath:self.indexPath];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {

}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale{
    
    [self contentScroller];
    
}

- (void)contentScroller{
    CGRect f = _imageView.frame;
    CGSize size = _scroll.frame.size;
    
    if(f.size.width < size.width){
        f.origin.x = (kScreenWidth - f.size.width)/2;
    }else{
        f.origin.x = 0.0f;
    }
    if(f.size.height < size.height){
        f.origin.y = (kScreenHeight - f.size.height)/2;
    }else{
        f.origin.y = 0.0f;
    }
    _imageView.frame = f;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    
    return _imageView;
}

- (void)setPicImageStr:(UIImage *)picImageStr {
    _picImageStr = picImageStr;
    self.conImage = picImageStr;
}
@end
