//
//  SRAlbumPreviewLayout.h
//  CameraDemo
//
//  Created by sharui on 2016/10/12.
//  Copyright © 2016年 sharui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IGAlbumPreviewLayout : UICollectionViewFlowLayout

@end
